#ifndef __DISP_DVE_H__
#define __DISP_DVE_H__

void DRV_DVE_Init(void *pInHWReg);
void DRV_DVE_SetMode(int mode);
void DRV_DVE_SetColorbar(int enable);

#endif	//__DISP_DVE_H__

