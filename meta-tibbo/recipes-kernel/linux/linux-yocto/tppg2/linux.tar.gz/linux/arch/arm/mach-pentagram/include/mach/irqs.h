#ifndef __MACH_IRQS_H
#define __MACH_IRQS_H

#define NR_IRQS 205

#endif /* __MACH_IRQS_H */
